var mode;
var s;
var scl = 20;
var heg;
var score = 0;
function preload(){ //for images
  hImg = loadImage("hedge.png");
  fImg = loadImage("flippedhedge.png");
  shImg = loadImage("shedge.png");
  sImg = loadImage("snake.png");
  gImg = loadImage("grass.jpg");
  dImg = loadImage("snakedead.png");
}

function setup() {
  mode = 0;
  createCanvas(600, 600);
  textSize(30);
  s = new Snake();//snakespawn
  frameRate(10);
  pickLocation();//snake location
}

function pickLocation(){ //how location is selected
  var cols = floor(width/scl);
  var rows = floor(height/scl);
  heg = createVector(floor(random(cols)), floor(random(rows)));
  heg.mult(scl);
  
}

function draw() {
  clear();
  if (mode ==0){ //title screen
    background(155, 235, 98);
    fill(255);
    textSize(10);
    text("Made by Sophia Corbett", 470, 20);
    textSize(47);
    fill(250, 0, 0);
    text('Hungry Snake', 225, 160);
    textSize(21);
    fill(255);
    text('move the snake to help get a hedgehog snack for lunch', 40, 200);
    fill(0, 0, 0);
    text('★ Use arrow keys to move snake', 10, 240);
    text("★ Don't run into the walls!", 10, 280);
    text("★ Don't hit the snakes tail either!", 10, 320);
    text("★ Press enter key to start, good luck :>", 10, 360);
    image(hImg, 310, 350, 280, 280);
    image(fImg, 6, 350, 280, 280);
    image(sImg, -90, -1, 290, 150);
  }
  if(mode ==2) { //game
    background(gImg);
   if (s.eat(heg)){
    pickLocation();
  }
  
  s.done();
  s.update();
  s.show();
  
  image(hImg, heg.x, heg.y, scl+13, scl+13); //target hedgehog
    
  fill(0);
  textSize(12);
  text("Score:", 7, 25);
  text(score, 46, 25);
    
 }
  if(mode ==3){ //end screen
    clear();
    background(184, 232, 255);
    image(dImg, 10, 190, 330, 330);
    fill(130, 130, 130);
    textSize(40);
    text("Tabitha the snake, 2018 - 2021", 30, 100);
    fill(89, 89, 89);
    textSize(50);
    text("Good try !", 170, 180);
    textSize(20);
    text("Thanks so much for playing!", 320, 315);
    image(shImg, 350, 390, 200, 200);
  }
}

function keyPressed(){ //player interaction
  if(keyCode === ENTER){
    mode = 2;
  }
  if (keyCode === UP_ARROW){
    s.dir(0, -1);
  } else if (keyCode === DOWN_ARROW){
    s.dir(0, 1);
  } else if (keyCode === LEFT_ARROW){
    s.dir(-1, 0);
  } else if (keyCode === RIGHT_ARROW){
    s.dir(1, 0);
}
}

